/*function Validation() 
	{
	
	var name = document.getElementById("name").value;
	var address = document.getElementById("address").value;
	var city = document.getElementById("city").value;
	var contact = document.getElementById("contact").value;
	var make = document.getElementById("make").value;
	var model = document.getElementById("Model").value;
	var year = document.getElementById("year").value;
	
	
	if (name == ' ')
	{
		document.getElementById('name').style.borderColor = "red";
	}
	
	return false; 
	
	
	}
	
*/
function abc()
	{
		
		var name = document.getElementById("name").value;
		var address = document.getElementById("address").value;
		var email = document.getElementById("email").value;
		var city = document.getElementById("city").value;
		var contact = document.getElementById("contact").value;
		var make = document.getElementById("make").value;
		var model = document.getElementById("model").value;
		var year = document.getElementById("year").value;	
		
		var result;
		Boolean(result);
		if (name == ""){
			document.getElementById('name').style.borderColor = "red";
			result = false;
		}
		else 
		{
			document.getElementById('address').style.borderColor = "black";
		}
		if (address == ""){
			document.getElementById('address').style.borderColor = "red";
			result = false;
		}
		
		if (city == ""){
			document.getElementById('city').style.borderColor = "red";
			result = false;
		}
		if (contact == ""){
			document.getElementById('contact').style.borderColor = "red";
			result = false;
		}
		if (make == ""){
			document.getElementById('make').style.borderColor = "red";
			result = false;
		}
		if (model == ""){
			document.getElementById('model').style.borderColor = "red";
			result = false;
		}
		if (year == ""){
			document.getElementById('year').style.borderColor = "red";
			result = false;
		}
		if (result == false)
		{
				alert('Please Enter valid data');
		}
		return result
		
	}