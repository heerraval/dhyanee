<!DOCTYPE php>
<html>
<script src ="script.js"></script>


<head>


</head>
	<body>
	<h1>Enter data</h1>
		<form action="display.php" method="post" onsubmit="return abc()">
		<label>Seller Name:</label> <input id="name" name="name"  type="text"></br>
		<label>Adress:</label> <input id="address" name="address"  type="text"></br>
		<label>Email:</label> <input id="email" name="email"  type="email"></br>
		<label>City:</label> <input id="city" name="city"  type="text"></br>
		<label>Phone No:</label> <input id="contact" name="contact"  type="text"></br>
		<label>Vehicle Make:</label> <input id="make" name="make"  type="text"></br>
		<label>Model:</label> <input id="model" name="model"  type="text"></br>
		<label>Year:</label> <input id="year" name="year"  type="text"></br>
		<input type="submit" value="Submit">
		</form>
	</body>

</html>