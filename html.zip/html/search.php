<?php include 'sql.php';?>
<style>.table ,th,td {
		border: 2px solid black;
}
</style>

<html>
<head>
<body>
<table class ="table">
<tr>
			<th>id</th>
			<th>Name</th>
			<th>address</th>
			<th>email</th>
			<th>city</th>
			<th>contact</th>
			<th>make</th>
			<th>model</th>
			<th>year</th>
			<th>link</th>
</tr>
<?php
$sql_query =   "SELECT id, name, address, email, city, phone_no, make, model, year, link from info order by id DESC;";
$data = $con->query($sql_query);
while ($table = $data->fetch_assoc())
{
	echo "<tr>
			<td>". $table["id"] ."</td>
			<td>". $table["name"] ."</td>
			 <td>". $table["address"] ."</td>
			 <td>". $table["email"] ."</td>
			 <td>". $table["city"] ."</td>
			 <td>". $table["phone_no"] ."</td>
			 <td>". $table["make"] ."</td>
			 <td>". $table["model"] ."</td> 
			 <td>". $table["year"] ."</td>
			 <td>". $table["link"] ."</td>
	</tr>";
}
echo "</table>";


?>
</table>

</body>
</head>
</html>


