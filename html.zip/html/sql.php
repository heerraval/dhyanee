<?php 
$servername = "localhost";
$username = "root";
$password = "";
$database = "demo";
//$con = new mysqli($servername, $username, $password, $database);
$con = mysqli_connect($servername, $username, $password, $database);
if (!$con) {
    die("Failed Connection: " . mysqli_connect_error());
	}
else 
	{
	//echo "successfull";
	}
?>	