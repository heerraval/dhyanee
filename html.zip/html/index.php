<!DOCTYPE php>
<html>
<head>
</head>
<body>
<h1>Select Option</h1>
<button onclick="window.location.href='new.php'" type="button">New</button> <button onclick="window.location.href='search.php'" type="search">Search</button>
</body>
</html>