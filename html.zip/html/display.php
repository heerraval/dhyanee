<?php include 'sql.php';?>

<?php
$name = $_REQUEST['name'];
$address = $_REQUEST['address'];
$email = $_REQUEST['email'];
$city = $_REQUEST['city'];
$contact = $_REQUEST['contact'];
$make = $_REQUEST['make'];
$model = $_REQUEST['model'];
$year = $_REQUEST['year'];
$link = "https://jdpower.com/Cars/$make/$model/$year";




$sql_query= "INSERT INTO `info`(`name`, `address`, `email`, `City`, `phone_no`, `make`, `model`, `year`, `link`) VALUES ('$name','$address','$email','$city','$contact','$make','$model','$year','$link')";

$con->query($sql_query);


?>
<style>.table ,th,td {
		border: 2px solid black;
}
</style>


<html>
<script src ="script.js"></script>


<head>


</head>
	<body>
	<table  class="table">
		<tr>
			<th>Name</th>
			<th>address</th>
			<th>email</th>
			<th>city</th>
			<th>contact</th>
			<th>make</th>
			<th>model</th>
			<th>year</th>
			<th>link</th>
		</tr>
		<tr><td><?php echo $name; ?></td>
			<td><?php echo $address; ?></td>
			<td><?php echo $email; ?></td>
			<td><?php echo $city; ?></td>
			<td><?php echo $contact; ?></td>
			<td><?php echo $make; ?></td>
			<td><?php echo $model; ?></td>
			<td><?php echo $year; ?></td>
			<td><a href="<?php echo $link; ?>"target="_blank"><?php echo $link; ?></a></td>
		</tr>
	</table>
	</body>

</html>